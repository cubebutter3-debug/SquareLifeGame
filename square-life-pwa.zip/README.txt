# Square Life — iOS PWA Package

This package turns the Square Life HTML game into a Progressive Web App (PWA) you can **Add to Home Screen** on iOS.

## Files
- `index.html` — the game with PWA hooks
- `manifest.json` — app metadata
- `sw.js` — service worker for offline cache
- `icons/icon-192.png`, `icons/icon-512.png`, `icons/icon-180.png` — app icons

## Deploy (GitHub Pages)
1. Create a new public repo on GitHub.
2. Upload **all files** in this folder to the repo root.
3. In the repo: **Settings → Pages → Build and deployment → Branch: `main` / root**.
4. Wait for the site URL to appear (e.g. `https://yourname.github.io/yourrepo/`).

## Deploy (Netlify)
1. Go to netlify.com, create a site, and **drag-drop** the folder.
2. Netlify gives you a URL like `https://your-site.netlify.app/`.

## Add to Home Screen (iOS)
1. Open your deployed URL in **Safari** on iPhone/iPad.
2. Tap the **Share** icon (square with arrow).
3. Choose **Add to Home Screen**.
4. Tap **Add**. The app icon appears on your Home Screen.
5. Launch from the icon — it opens full-screen, offline-ready.

> Note: iOS requires the site to be served over **https** and the pages to be loaded at least once while online before it works offline.
